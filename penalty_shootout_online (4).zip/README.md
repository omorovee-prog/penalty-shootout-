# Penalty Shootout Online

A real-time 2-player web game using Node.js + WebSockets.

## Game rules
- Exactly 2 players per room.
- Players alternate kicks.
- 5 rounds, one kick per player per round.
- Shooter chooses LEFT, CENTER, or RIGHT.
- The server randomly chooses the goalkeeper's dive.
- If the keeper chooses the same direction, the shot is saved; otherwise it is a goal.
- Highest score after round 5 wins.
- A tie starts sudden death. Players continue one kick at a time until the scores differ after equal turns.
- The server is authoritative, so both devices receive the same result.

## Run locally
Install Node.js, then:
npm install
npm start

Open http://localhost:3000 on one device.

For another device on the same Wi-Fi, use your computer's local network IP, for example:
http://192.168.1.20:3000

## Make it public
Deploy the folder to a Node.js host that supports WebSockets. Set the start command to:
npm start
The service must expose port 3000 (or use its PORT environment variable).

After deployment, share the HTTPS URL. Each player can open the URL on a different phone/computer and use the room code.

## Production upgrades
- QR code for joining
- avatars/photos
- accounts and persistent stats
- matchmaking
- tournaments
- sound and better animations
- rate limiting/authentication
- database for rooms and leaderboards
