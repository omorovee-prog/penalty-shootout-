const express=require("express");
const http=require("http");
const {WebSocketServer}=require("ws");
const path=require("path");

const app=express();
const server=http.createServer(app);
const wss=new WebSocketServer({server});
app.use(express.static(path.join(__dirname,"public")));

const rooms=new Map();
const send=(ws,o)=>ws.readyState===1&&ws.send(JSON.stringify(o));
const broadcast=(room,o)=>room.players.forEach(p=>send(p.ws,o));
const code=()=>{let c;do c=Math.random().toString(36).slice(2,6).toUpperCase();while(rooms.has(c));return c};

function publicState(room){
  const ps=[...room.players.values()];
  return {type:"state",room:room.code,phase:room.phase,round:room.round,
    maxRounds:5,turnPlayerId:room.turnPlayerId,message:room.message,
    players:ps.map(p=>({id:p.id,name:p.name,score:p.score,kicks:p.kicks}))};
}
function startRound(room){
  const ps=[...room.players.values()];
  room.turnPlayerId=ps[room.roundTurn%2]?.id||null;
}
function resetRoom(room){
  room.round=1;room.roundTurn=0;room.turnPlayerId=null;room.phase="playing";
  room.busy=false;room.message="Player 1 shoots first.";
  room.players.forEach(p=>{p.score=0;p.kicks=0});
  startRound(room);
}
function winnerAfterRound(room){
  const ps=[...room.players.values()];
  if(ps.length<2)return null;
  if(room.round<5)return null;
  if(ps[0].score!==ps[1].score)return ps[0].score>ps[1].score?ps[0]:ps[1];
  return null;
}

wss.on("connection",ws=>{
  const id=Math.random().toString(36).slice(2,9);
  ws.id=id;ws.room=null;

  ws.on("message",raw=>{
    let m;try{m=JSON.parse(raw)}catch{return}

    if(m.type==="create"){
      const room={code:code(),players:new Map(),phase:"waiting",round:1,roundTurn:0,
        turnPlayerId:null,message:"Waiting for Player 2...",busy:false};
      rooms.set(room.code,room);
      room.players.set(id,{id,ws,name:String(m.name||"Player 1").slice(0,18),score:0,kicks:0});
      ws.room=room;
      send(ws,{type:"joined",id,room:room.code});
      broadcast(room,publicState(room));
      return;
    }

    if(m.type==="join"){
      const room=rooms.get(String(m.room||"").toUpperCase());
      if(!room)return send(ws,{type:"error",message:"Room not found."});
      if(room.players.size>=2)return send(ws,{type:"error",message:"This room is full."});
      room.players.set(id,{id,ws,name:String(m.name||"Player 2").slice(0,18),score:0,kicks:0});
      ws.room=room;
      resetRoom(room);
      broadcast(room,publicState(room));
      return;
    }

    if(m.type==="kick"){
      const room=ws.room,p=room&&room.players.get(id);
      if(!room||room.phase!=="playing"||room.busy||!p||room.turnPlayerId!==id)return;
      if(!["left","center","right"].includes(m.direction))return;

      room.busy=true;
      const keeper=["left","center","right"][Math.floor(Math.random()*3)];
      const goal=m.direction!==keeper;
      p.kicks++;
      if(goal)p.score++;
      room.message=goal?`${p.name} SCORES!`:`${p.name} is SAVED!`;

      broadcast(room,{type:"shot",playerId:id,direction:m.direction,keeper,goal});
      setTimeout(()=>{
        room.busy=false;
        room.roundTurn++;
        if(room.roundTurn%2===0){
          const winner=winnerAfterRound(room);
          if(winner){
            room.phase="finished";
            room.message=`${winner.name} wins ${winner.score}-${[...room.players.values()].find(x=>x.id!==winner.id).score}!`;
          }else if(room.round>=5){
            room.round=6;
            room.message="DRAW — SUDDEN DEATH!";
            room.roundTurn=0;
            startRound(room);
          }else{
            room.round++;
            startRound(room);
            room.message=`Round ${room.round}: ${[...room.players.values()].find(x=>x.id===room.turnPlayerId).name} shoots.`;
          }
        }else{
          startRound(room);
          room.message=`${[...room.players.values()].find(x=>x.id===room.turnPlayerId).name} shoots.`;
        }
        broadcast(room,publicState(room));
      },900);
      return;
    }

    if(m.type==="restart"){
      const room=ws.room;
      if(!room||room.players.size<2)return;
      resetRoom(room);
      broadcast(room,publicState(room));
    }
  });

  ws.on("close",()=>{
    const room=ws.room;if(!room)return;
    room.players.delete(id);
    if(!room.players.size)rooms.delete(room.code);
    else{room.phase="waiting";room.turnPlayerId=null;room.message="Opponent disconnected.";broadcast(room,publicState(room))}
  });
});

const PORT=process.env.PORT||3000;
server.listen(PORT,()=>console.log(`Penalty Shootout running on ${PORT}`));
