let ws=null,myId=null;
const $=x=>document.getElementById(x);
function connect(done){
  const proto=location.protocol==="https:"?"wss":"ws";
  ws=new WebSocket(`${proto}://${location.host}`);
  ws.onopen=done;
  ws.onmessage=e=>handle(JSON.parse(e.data));
  ws.onclose=()=>{$("connection").textContent="OFFLINE"};
}
function send(x){if(ws?.readyState===1)ws.send(JSON.stringify(x))}
function createGame(){connect(()=>send({type:"create",name:$("name").value.trim()||"Player 1"}))}
function joinGame(){connect(()=>send({type:"join",room:$("room").value.trim().toUpperCase(),name:$("name").value.trim()||"Player 2"}))}
function handle(m){
 if(m.type==="error"){alert(m.message);return}
 if(m.type==="joined"){myId=m.id;$("lobby").classList.add("hidden");$("game").classList.remove("hidden");$("roomCode").textContent=m.room}
 if(m.type==="state"){
   $("connection").textContent="LIVE";
   $("round").textContent=m.round>5?"SUDDEN DEATH":`ROUND ${m.round} OF 5`;
   $("message").textContent=m.message;
   $("scoreboard").innerHTML=m.players.map(p=>`<div class="player ${p.id===m.turnPlayerId&&m.phase==="playing"?"active":""}"><b>${esc(p.name)}</b><br>⚽ ${p.score} / ${p.kicks}</div>`).join("");
   const myTurn=m.turnPlayerId===myId&&m.phase==="playing";
   document.querySelectorAll(".shoot button").forEach(b=>b.disabled=!myTurn);
   $("again").classList.toggle("hidden",m.phase!=="finished");
 }
 if(m.type==="shot"){
   const keeper=$("keeper"),ball=$("ball");
   const k={left:"-90px",center:"0px",right:"90px"}[m.keeper];
   const b={left:"-170px",center:"0px",right:"170px"}[m.direction];
   keeper.style.transform=`translateX(${k})`;
   ball.style.transform=`translate(${b},-170px) scale(.65)`;
   setTimeout(()=>{keeper.style.transform="";ball.style.transform=""},850);
 }
}
function kick(d){send({type:"kick",direction:d})}
function restart(){send({type:"restart"})}
function esc(s){return s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
